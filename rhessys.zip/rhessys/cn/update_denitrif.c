/*--------------------------------------------------------------*/
/*                                                              */
/*		update_denitrif				*/
/*                                                              */
/*  NAME                                                        */
/*		update_denitrif				*/
/*                                                              */
/*                                                              */
/*  SYNOPSIS                                                    */
/*  void update_denitrif(				*/
/*                                                              */
/*			struct  soil_c_object   *               */
/*                      struct  soil_n_object   *               */
/*                      struct  cdayflux_patch_object *         */
/*                      struct  ndayflux_patch_object *         */
/*			struct	soil_class 			*/
/*			double					*/
/*			double					*/
/*			double					*/
/*                              )                               */
/*  OPTIONS                                                     */
/*                                                              */
/*                                                              */
/*  DESCRIPTION                                                 */
/*	compute nitrification and denitrification 		*/
/*	based on soil temperature, moisture, heter. resp,	*/
/*	soil texture, and C substrate, N avaiilability		*/
/*	based on relationships derived in			*/ 
/*	effect of PH currently and excess NH4			*/
/*      currently ignored					*/
/*								*/
/*	Parton et al. 1996. Generalized model of N2 and N20 	*/
/*	production, Global Biogeochemical cycles, 10:3		*/
/*	401-412							*/
/*                                                              */
/*								*/
/*  PROGRAMMER NOTES                                            */
/*                                                              */
/*                                                              */
/*--------------------------------------------------------------*/

#include "rhessys.h"
#include <stdio.h>
#include <math.h>

//int    update_denitrif(
//                       struct  soil_c_object   *,
//                       struct  soil_n_object   *,
//                       struct cdayflux_patch_struct *,
//                       struct ndayflux_patch_struct *,
//                       struct patch_object *,
//                       struct command_line_object *,
//                       double);

int update_denitrif(
					struct  soil_c_object   *cs_soil,
					struct  soil_n_object   *ns_soil,
					struct cdayflux_patch_struct *cdf,
					struct ndayflux_patch_struct *ndf,
                    struct patch_object *patch,
                    struct command_line_object *command_line,
					double std)
{
//    struct  soil_class   soil_type, = patch[0].soil_defaults[0][0].soil_type
//    double  theta, = patch[0].rootzone.S
	/*------------------------------------------------------*/
	/*	Local Function Declarations.						*/
	/*------------------------------------------------------*/
	
	/*------------------------------------------------------*/
	/*	Local Variable Definition. 							*/
	/*------------------------------------------------------*/
	int ok,i;
	double denitrify;
	double a, b, c, d;
	double water_scalar, theta, thetai, water_scalari, kg_soil, depth;
    double active_zone_z;
    double decay_rate;
    double perc_inroot;
	double fnitrate, fCO2;
	double hr, nitrate_ratio;
    #define  PARTICLE_DENSITY    2.65    /* soil particle density g/cm3 (Dingman) */
	#define NUM_NORMAL  10 	/* resolution of normal distribution */
	double NORMAL[10]= {0,0,0.253,0.524,0.842,1.283,-0.253,-0.524,-0.842,-1.283};
	
	ok = 1;
	if ((ns_soil->nitrate > 0.0) && patch[0].soil_defaults[0][0].soil_water_cap>0.0) {
        
//        theta = max(min((patch[0].unsat_storage+patch[0].rz_storage+patch[0].soil_defaults[0][0].soil_water_cap-patch[0].sat_deficit)/ patch[0].soil_defaults[0][0].soil_water_cap,1.0),0.0);
        theta = patch[0].rootzone.S;
        //if ((theta <= ZERO) || (theta > 1.0)) theta = 1.0;
		/*--------------------------------------------------------------*/
		/*	compute denitrification rate				*/
		/*	- assuming a constant nitrification rate		*/
		/*--------------------------------------------------------------*/
		if (patch[0].soil_defaults[0][0].soil_type.sand > 0.5) {
			a = 1.56; b=12.0; c=16.0; d=2.01;
		}
		else if (patch[0].soil_defaults[0][0].soil_type.clay > 0.5) {
			a = 60.0; b=18.0; c=22.0; d=1.06;
		}
		else {
			a=4.82; b=14.0; c=16.0; d=1.39;
		}

		water_scalar = 0.0;
		if (std > 0) {
			for (i =1; i< NUM_NORMAL; i++) {
				thetai = theta + std*NORMAL[i];
				thetai = min(1.0, thetai);
				thetai = max(0.0, thetai);
				if (thetai > ZERO)
				water_scalari = min(1.0,a / pow(b,  (c / pow(b, (d*thetai) )) ));
				water_scalar += 1.0/NUM_NORMAL * water_scalari;
				}
			}
		else
				water_scalar = min(1.0,a / pow(b,  (c / pow(b, (d*theta) )) ));

        depth = patch[0].rootzone.depth * 1.2;
        kg_soil = PARTICLE_DENSITY * (depth - patch[0].soil_defaults[0][0].porosity_0*patch[0].soil_defaults[0][0].porosity_decay * (1- exp(-depth/patch[0].soil_defaults[0][0].porosity_decay))) * 1000.0;
        
        active_zone_z = (command_line[0].rootNdecayRate > 0? patch[0].soil_defaults[0][0].soil_depth : (command_line[0].root2active > 0.0? patch[0].rootzone.depth * command_line[0].root2active : patch[0].soil_defaults[0][0].active_zone_z));
        decay_rate = (command_line[0].rootNdecayRate > 0? patch[0].rootzone.NO3decayRate : patch[0].soil_defaults[0][0].N_decay_rate);
        perc_inroot = max(1 - (1.0-exp(-decay_rate * depth)) / (1.0 - exp(-decay_rate * active_zone_z)),0.0);
        nitrate_ratio = ns_soil->nitrate * perc_inroot / kg_soil * 1000000.0; //<<---- Parton et al. 1996 (µgN/g soil)
		//nitrate_ratio = (ns_soil->nitrate) / (cs_soil->totalc + ns_soil->totaln) * 1e6; //<<---- original
		/*--------------------------------------------------------------*/
		/*	maximum denitrfication (kg/ha) based on available	*/
		/*		N03							*/
		/*--------------------------------------------------------------*/
		fnitrate = atan(PI*0.002*(nitrate_ratio - 180)) * 0.004 / PI + 0.0011; // gN/ha/day --> 1e-07 kgN/m2/day
        // nitrate_ratio is 1000000.0 µgN/g soil = 1000000.0 mgN / kg soil = kgN / kg soil
		/*--------------------------------------------------------------*/
		/*	maximum denitrfication (kg/ha) based on available	*/
		/*	carbon substrate - estimated from heter. respiration    */
		/*--------------------------------------------------------------*/
		hr = (cdf->soil1c_hr + cdf->soil2c_hr + cdf->soil3c_hr + cdf->soil4c_hr);
        // hr is kgC/ha/day <---- 10000 kgC/m2/day
        // 1 ha = 10000 m2
		if (hr > 0.0)
			fCO2 = 0.0024 / (1+ 200.0/exp(0.35*hr*10000.0)) - 0.00001;
		else
			fCO2 = 0.0;
		/*--------------------------------------------------------------*/
		/*	estimate denitrification				*/
		/*--------------------------------------------------------------*/
		denitrify = min(fCO2, fnitrate) * water_scalar;
	} /* end mineralized N available */
	else
		denitrify = 0.0;
	/*--------------------------------------------------------------*/
	/*	update state and flux variables				*/
	/*--------------------------------------------------------------*/
	denitrify = min(denitrify, ns_soil->nitrate * perc_inroot);
	denitrify = max(0.0, denitrify);
    //denitrify = 0.0;
    
	ns_soil->nvolatilized_snk += denitrify;
	ndf->sminn_to_nvol = denitrify;
	ns_soil->nitrate -= denitrify;
	ndf->denitrif = denitrify;
	ok = 0;
	return(ok);
} /* end update_denitrif */
