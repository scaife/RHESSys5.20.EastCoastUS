/*--------------------------------------------------------------*/
/*                                                              */
/*		update_nitrif				*/
/*                                                              */
/*  NAME                                                        */
/*		update_nitrif				*/
/*                                                              */
/*                                                              */
/*  SYNOPSIS                                                    */
/*  void update_nitrif(				*/
/*                                                              */
/*			struct  soil_c_object   *               */
/*                      struct  soil_n_object   *               */
/*                      struct  cdayflux_patch_object *         */
/*                      struct  ndayflux_patch_object *         */
/*			struct	soil_class 			*/
/*			double					*/
/*			double					*/
/*			double					*/
/*                              )                               */
/*  OPTIONS                                                     */
/*                                                              */
/*                                                              */
/*  DESCRIPTION                                                 */
/*	compute nitrification and nitrification 		*/
/*	based on soil temperature, moisture, heter. resp,	*/
/*	soil texture, and C substrate, N avaiilability		*/
/*	based on relationships derived in			*/ 
/*								*/
/*	effect of pH from Parton et al 2004			*/
/*      pH equation from tropical acidic soils                  */
/*      effect of excess NH4                                    */
/*      currently ignored					*/
/*								*/
/*	Parton et al. 1996. Generalized model of N2 and N20 	*/
/*	production, Global Biogeochemical cycles, 10:3		*/
/*	401-412							*/
/*                                                              */
/*								*/
/*  PROGRAMMER NOTES                                            */
/*                                                              */
/*                                                              */
/*--------------------------------------------------------------*/
#include "rhessys.h"
#include "phys_constants.h"
#include <stdio.h>
#include <math.h>

#define  PARTICLE_DENSITY	2.65	/* soil particle density g/cm3 (Dingman) */
#define	 MAX_PERC		0.1	/* fraction of amonium that goes to nitrate */
#define  MAX_RATE		(1.5*0.1353535)  //120	/* mgN/kg soil/day twice groffman values for ag soils */
#define NUM_NORMAL  10 	/* resolution of normal distribution */
double NORMAL[10]= {0,0,0.253,0.524,0.842,1.283,-0.253,-0.524,-0.842,-1.283};


int update_nitrif(
				  struct  soil_c_object   *cs_soil,
				  struct  soil_n_object   *ns_soil,
				  struct cdayflux_patch_struct *cdf,
				  struct ndayflux_patch_struct *ndf,
				  struct patch_object *patch,
                  struct command_line_object *command_line,
				  double std)
{
	/*------------------------------------------------------*/
	/*	Local Function Declarations.						*/
	/*------------------------------------------------------*/
	
	/*------------------------------------------------------*/
	/*	Local Variable Definition. 							*/
	/*------------------------------------------------------*/
	int ok,i;
	double nitrify;
	double a, b, c, d;
	double nh4_conc, bulk_density, kg_soil;
	double N_scalar, water_scalar, T_scalar, pH_scalar;
	double theta, thetai;
	double max_nit_rate; /* kg/m2/day */
    double active_zone_z;
    double decay_rate;
    double perc_inroot;
    double sat_def, depth;
    double unsat;
    
	ok = 1;
    sat_def = patch[0].sat_deficit;
    depth = min(max(patch[0].sat_deficit_z,0.0), patch[0].rootzone.depth * 1.2);
    unsat = patch[0].unsat_storage;
    
	if( ns_soil->sminn > 0.0 && depth > 0.0) {
        
        max_nit_rate = 0.0;
        theta = max(min(patch[0].rootzone.S, 1.0), 0.0);
        //if ((theta <= ZERO) || (theta > 1.0)) theta = 1.0;

        /*--------------------------------------------------------------*/
        /* estimate bulk density from porosity and assuming a particle density */
        /*     of 2.65 g/cm3 (Dingman)                    */
        /* and convert to kg/m3                        */
        /* really should integrate depth to account for variable porosity    */
        /* but for now assume constant                    */
        /* and should be done once in construction of soil defaults    */
        /*--------------------------------------------------------------*/
        //bulk_density = PARTICLE_DENSITY * (1.0 - porosity) * 1000; <<--- 1000 is converting unit to kg/m3
        //max_nit_rate = kg_soil * MAX_RATE * 0.000001; why dividied by 1000000?
        //  (2.65*0.5*1000*0.25) * (3*0.1353535) * 0.000001 = 0.0001345075

        //bulk_density = PARTICLE_DENSITY * (1.0 - porosity) * 1000;
        //kg_soil = bulk_density * organic_soil_depth; //kg soilOM/m2  //<-- organic_soil_depth = 0.25 m and unit area 1 m2
        //kg_soil = PARTICLE_DENSITY * ((1.0 - porosity) * organic_soil_depth) * 1000;
        //kg_soil = PARTICLE_DENSITY * (non-pore space) * 1000;
        // 1000000 cm3 = 1 m3; 2.64 g/cm3 --> (1/1000 kg) /(1/1000000 m3) --> 1000 kg/m3


        //in case "sat_def_z" is updated at line 2078, just above this function called.
        kg_soil = PARTICLE_DENSITY * (depth - patch[0].soil_defaults[0][0].porosity_0*patch[0].soil_defaults[0][0].porosity_decay * (1- exp(-depth/patch[0].soil_defaults[0][0].porosity_decay))) * 1000.0; // correct


            max_nit_rate = kg_soil * MAX_RATE * 1e-06; // (mgN/kg soil/day) * (kg soil/m2) ==> mgN/m2/day ==> 1e-06 kgN/m2/day
            //  (2.65*0.5*1000) * (3*0.1353535) * 1e-06 = 0.0005380302 at 1 meter
            // 1 kg = 1000000 mg



            /*--------------------------------------------------------------*/
            /* compute ammonium conc. in ppm    (vol conc.)            */
            /*--------------------------------------------------------------*/
            active_zone_z = (command_line[0].NH4root2active>0.0? patch[0].rootzone.depth * command_line[0].NH4root2active : (command_line[0].rootNdecayRate > 0? patch[0].soil_defaults[0][0].soil_depth : (command_line[0].root2active>0.0? patch[0].rootzone.depth * command_line[0].root2active : patch[0].soil_defaults[0][0].active_zone_z)));
            decay_rate = (command_line[0].NH4root2active>0.0? patch[0].soil_defaults[0][0].N_decay_rate : (command_line[0].rootNdecayRate > 0? patch[0].rootzone.NH4decayRate : patch[0].soil_defaults[0][0].N_decay_rate));
            perc_inroot = (1.0-exp(-decay_rate * depth)) / (1.0 - exp(-decay_rate * active_zone_z));
            perc_inroot = max(0.1,min(perc_inroot,1.0));

            nh4_conc = ns_soil->sminn * perc_inroot / kg_soil * 1000000.0; // (kgN/m2) / kg soil/m2)

            /*--------------------------------------------------------------*/
            /* effect of ammonium conc on nitrification            */
            /*--------------------------------------------------------------*/
            N_scalar = 1.0 - exp(-0.0105 * nh4_conc);
            //if(N_scalar > 1.0) printf("update_nitfic error: N_scalar = %lf\n",N_scalar);
            // "nh4_conc" is 1000000.0 µgN/g soil = 1000000.0 mgN / kg soil = kgN / kg soil;
            // to make this function < 1, nh4_conc need to less than 0.001 kgN / kg soil

            /*--------------------------------------------------------------*/
            /*    compute effect of water and temperature on nitrification */
             /*--------------------------------------------------------------*/
            if (patch[0].soil_defaults[0][0].soil_type.sand > 0.5) {
                a = 0.55; b=1.7; c=-0.007; d=3.22;
            }
            else {
                a=0.6; b=1.27; c=0.0012; d=2.84;
            }

            water_scalar = 0.0;
            if (std > ZERO) {
                for (i=0; i<NUM_NORMAL; i++) {
                    thetai = theta + NORMAL[i]*std;
                    thetai = min(1.0, thetai);
                    thetai = max(0.0, thetai);
                    water_scalar  += 1.0/NUM_NORMAL * (
                             pow( ((thetai -b) / (a-b)), d*(b-a)/(a-c))
                            * pow( ((thetai-c)/ (a-c)), d) );
                }//for
            } else {
                if (theta  > c)
                    water_scalar  = pow( ((theta -b) / (a-b)), d*(b-a)/(a-c))
                    * pow( ((theta-c)/ (a-c)), d);
                else
                    water_scalar = 0.000001;
            }//if
            water_scalar = min(water_scalar,1.0);
            //if(water_scalar > 1.0) printf("update_nitfic error: water_scalar = %lf\n",water_scalar);


            T_scalar = min(-0.06 + 0.13 * exp(0.07 * patch[0].Tsoil),1.0);
            //if (T_scalar < 0.0) T_scalar = 0.0;
            //if(T_scalar > 1.0) printf("update_nitfic error: T_scalar = %lf\n",T_scalar);

            /*--------------------------------------------------------------*/
            /* effect of pH on nitrification                                */
            /*--------------------------------------------------------------*/
            pH_scalar = 0.56 + (atan(PI*0.45*(-5+patch[0].PH))/PI); //7.0
            //if(pH_scalar > 1.0) printf("update_nitfic error: pH_scalar = %lf\n",pH_scalar);

            /*--------------------------------------------------------------*/
            /*    estimate nitrification                */
            /*     by scaling a maximum rate suggested by Parton et al.        */
            /*--------------------------------------------------------------*/
            // #define  MAX_RATE        0.1353535  //120    /* mgN/kg soil/day twice groffman values for ag soils */
            // max_nit_rate = kg_soil * MAX_RATE * 0.000001; //mgN/kg soil/day <<-----
            //nitrify = water_scalar * T_scalar * N_scalar * pH_scalar * (MAX_RATE * ns_soil->sminn) * 1000.0; //<----- original
            nitrify = water_scalar * pH_scalar * T_scalar * N_scalar * max_nit_rate; //<----- Parton et al. 1996 (kgN/m2/day)


        /* end mineralized N available */


        /*--------------------------------------------------------------*/
        /*    update state and flux variables                */
        /*     convert from g to kg                    */
        /*--------------------------------------------------------------*/

        nitrify = max(min(nitrify, ns_soil->sminn * perc_inroot),0.0);
        //nitrify = min(nitrify, max_nit_rate);
        //nitrify = 0.0;
        
        // nitrify = kgN/m2/day
        ndf->sminn_to_nitrate = nitrify;
        ns_soil->sminn -= nitrify;
        ns_soil->nitrate += nitrify;
        //kg_soil > =0
    }else{
        //kg_soil ==0
        ndf->sminn_to_nitrate = 0.0;
    }
    ok = 0;
	return(ok);
} /* end update_nitrif */

